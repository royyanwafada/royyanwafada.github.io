<?php
$domain = "http://localhost/alma/";
?>
