<?php 
include_once "domain.php";

$menubar = 
"                   
<div class=\"left-side d-flex align-items-center\">
    <div class=\"logo\">
        <a href=\"http://localhost/alma\"><img src=\"http://localhost/alma/assets/img/logo/logonew5.png\" alt=\"\"></a>
    </div>

    <div class=\"main-menu d-none d-lg-block\">
        <nav>
            <ul id=\"navigation\">
                <li><a href=\"http://localhost/alma/\">Home</a></li>
                <li><a href=\"#\">About Us</a>
                    <ul class=\"submenu\">
                        <li><a href=\"http://localhost/alma/profil/\">Visi, Misi & Sejarah</a></li>
                        <li><a href=\"http://localhost/alma/guru-staff/\">Guru dan Staff</a></li>
                    </ul>
                </li>
                <li><a href=\"#\">Student</a>
                    <ul class=\"submenu\">
                        <li><a href=\"#\">OSIS</a></li>
                        <li><a href=\"#\">Extracurricular</a></li>
                        <li><a href=\"#\">Xpresia</a></li>
                        <li><a href=\"#\">Graduate Profile</a></li>
                    </ul>
                </li>
                <li><a href=\"#\">Facilities</a>
                    <ul class=\"submenu\">
                        <li><a href=\"#\">Infrastructure</a></li>
                        <li><a href=\"#\">E-learning</a></li>
                        <li><a href=\"#\">E-library</a></li>
                    </ul>
                <li><a href=\"http://localhost/alma/ppdb/\">PPDB</a></li>
                <li><a href=\"contact.html\">Gallery</a></li>
                <li><a href=\"http://localhost/alma/kontak/\">Contact</a></li>
            </ul>
        </nav>
    </div>
</div>
<div class=\"header-right-btn d-flex f-right align-items-center\">
    <a href=\"https://wa.me/6285163006904?text=Halo%20Assalamualaikum\" class=\"header-btn2 d-none d-xl-inline-block\">WhatsApp:<span> +62851-6300-6904</span></a>
    <ul class=\"header-social d-none d-sm-block\">
        <!--<li><a href=\"#\"><i class=\"fab fa-facebook-square\"></i></a></li>
        <li><a href=\"#\"><i class=\"fab fa-twitter-square\"></i></a></li>
        <li><a href=\"#\"><i class=\"fab fa-linkedin\"></i></a></li>
        <li><a href=\"#\"><i class=\"fab fa-youtube-square\"></i></a></li>
        <li><a href=\"#\"><i class=\"fas fa-envelope\"></i></a></li>-->
    </ul>
</div>
";?>
