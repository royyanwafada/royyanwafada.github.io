<?php echo'

<div class="main-header ">
    <div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="d-flex justify-content-center flex-wrap align-items-center">
                        <div class="header-info-left">
                        <ul>
                            <li><span>SEGERA BERAKHIR :</span> Penerimaan Peserta Didik Baru</li>
                        </ul>
                        </div>

                        <div class="header-info-right d-flex align-items-center">
                            <div class="cd-timer" id="countdown">
                                <div class="cd-item">
                                    <span>40</span>
                                        <p>Days</p>
                                </div>
                                <div class="cd-item">
                                    <span>18</span>
                                    <p>Hours</p>
                                </div>
                                <div class="cd-item">
                                    <span>46</span>
                                    <p>Minutes</p>
                                </div>
                                <div class="cd-item">
                                    <span>32</span>
                                    <p>Seconds</p>
                                </div>
                            </div>

                        <a href="#" class="browse-btn browse-btn2 ml-40 d-none d-sm-block">Info Detail</a>    
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




'; ?>