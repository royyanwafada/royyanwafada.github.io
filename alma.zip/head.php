<?php
include_once "domain.php";

$head = "
<meta charset=\"utf-8\">
<meta http-equiv=\"x-ua-compatible\" content=\"ie=edge\">
<meta name=\"description\" content=\"\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"".$domain."/assets/img/icon/xfavicon.png.pagespeed.ic.VDbWx8TeWc.png\">
<link rel=\"stylesheet\" href=\"".$domain."/assets/css/bootstrap.min.css%2bowl.carousel.min.css%2bslicknav.css%2banimate.min.css%2bmagnific-popup.css%2bfontawesome-all.min.css%2bthemify-icons.css%2bslick.css%2bnice-select.css.pagespeed\" />
<link rel=\"stylesheet\" href=\"".$domain."/assets/css/A.style.css.pagespeed.cf.ihVIXitPqH.css\">
";
?>